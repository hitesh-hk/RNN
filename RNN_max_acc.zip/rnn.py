import numpy as np

class rnn():
    
    def __init__(self,input_dim,hidden_dim):
        
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim 
#        self.W = W
#        self.B = B
        self.gradW = np.zeros(((input_dim+hidden_dim),hidden_dim))
        self.gradB = np.zeros(hidden_dim)
        ''' To be modified '''
        self.output = np.zeros(hidden_dim)
        
    def forward(self,input,W,B):
        ''' input shud be onhot+hprev'''
        theta = np.dot(input,W) + B
        self.output = np.tanh(theta)
        return self.output
        
    def backward(self,input,gradOutput,W):
        
        actGrad = 1-self.output**2
        self.gradB = gradOutput*actGrad
        ''' Instead of W, it should be W_hh'''
        gradInput = np.dot(gradOutput*actGrad,W[self.input_dim:,:].T)
        self.gradW = np.array(np.matrix(input).T*np.matrix(gradOutput*actGrad))
#        print(self.gradW.shape)
#        print("\n")
#        print(self.gradB.shape)
        ''' regularization '''
        norm_gradIn = np.linalg.norm(gradInput)
        norm_gradOt = np.linalg.norm(gradOutput)
        gradInput *= ((0.01+norm_gradOt)/(0.01+norm_gradIn))
#        print(str(norm_gradIn)+':'+str(norm_gradOt))
        return gradInput
