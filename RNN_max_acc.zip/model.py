import numpy as np
from rnn import *

class model():

    def forward(self,input,h):
        
        self.h0 = np.copy(h)
        self.hprev = np.copy(h)
        
        for t in range(self.nLayers):
            self.hprev=self.layer[t].forward(np.concatenate((input[t],self.hprev)),self.Wxh_hh,self.Bxh_hh)
        output = np.dot(self.hprev,self.Wxy)
        
        return output,self.hprev

    def forward_test(self,inp,h):
        
        hp = np.copy(h)
        l = len(inp)
        for t in range(l):
            hp = self.layer[0].forward(np.concatenate((inp[t],hp)),self.Wxh_hh,self.Bxh_hh)
        output = np.dot(hp,self.Wxy)
        
        return output
        
    def backward(self,input,gradLoss):
        
        upper_bound = self.nLayers -1
        lower_bound = -1
        decr = -1
        gradOutput = np.dot(gradLoss,self.Wxy.T)
        for t in range(upper_bound, lower_bound, decr):
            if t==0:
                h = self.h0
            else:
                h = self.layer[t-1].output
            gradOutput = self.layer[t].backward(np.concatenate((input[t],h)), gradOutput,self.Wxh_hh)
        
        self.gradWxy = np.array(np.matrix(self.hprev).T*np.matrix(gradLoss))

    def addlayer(self,layer_object):
        
        self.layer.append(layer_object)
    
    def update(self,learn_rate):
        
        cumlGradBxh_hh = np.zeros_like(self.Bxh_hh)
        cumlGradWxh_hh = np.zeros_like(self.Wxh_hh)

        for layer in self.layer:
            cumlGradBxh_hh += layer.gradB
            cumlGradWxh_hh += layer.gradW
            layer.gradW = 0
            layer.gradB = 0
            
        self.Wxh_hh -= learn_rate*cumlGradWxh_hh 
        self.Bxh_hh -= learn_rate*cumlGradBxh_hh
        self.Wxy -= learn_rate*self.gradWxy

    def __init__(self,nLayers,H,V,D,isTrain):
        
        self.layer = []
        self.nLayers = nLayers # no_of_layers
        self.hidden_dim = H # hidden_layer_dim
        self.V = V # no_of_words_in_vocab
        self.input_dim = D # word_vector_size
        self.isTrain = isTrain   
        self.Wxh_hh = np.random.randn((self.input_dim+self.hidden_dim),self.hidden_dim)*0.1
        self.Bxh_hh = np.random.randn(self.hidden_dim)*0.1
        self.Wxy = np.random.randn(self.hidden_dim,2)*0.1
        for t in range(nLayers):
            self.addlayer(rnn(self.input_dim,self.hidden_dim))
            ''' To be changed in case of batches '''
