import numpy as np

class criterion():
    
    def softmax(self,inp):
        
        i = np.copy(inp)
        i -= np.max(i)
        exp_op = np.exp(i)
        norm_exp = exp_op/exp_op.sum()
        
        return norm_exp    
        
    def forward(self,input,target):

        log_loss = -np.log(self.softmax(input))
        avg_loss = log_loss[target]
        
        return avg_loss
    
    def backward(self,input,target):

        onhot=np.zeros_like(input)
        onhot[target]=1
        
        gradLoss = self.softmax(input) - onhot
        
        return gradLoss
            

    
